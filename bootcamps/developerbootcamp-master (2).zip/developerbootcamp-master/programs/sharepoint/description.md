The SharePoint Deployment Specialist program includes coverage of how to deploy, configure, manage and customize the SharePoint 2013 environment. Coverage also includes HTML5, CSS3 and jQuery to create Web sites that target the capabilities of modern browsers.

Courses can be taken either face-to-face in the classroom or via remote attendance. Remote attendance connects students to a live classroom presentation that includes a mix of in-person and remote students. You decide which courses to attend in person or remotely. All programming courses include at least 50% of time performing comprehensive hands on exercises facilitated by expert instructors. This boosts retention and confidence as well as assuring competency with the new skills being acquired.

Our self-directed scheduling allows you the flexibility you require to complete your training in the time frame you need.

The Microsoft .NET Developer teaches the skills needed to create distributed applications and dynamic web applications with the .NET platform using C# or VB.NET. The program includes optional courses in WPF, WCF, SQL Programming and OOA&D.

Courses can be taken either face-to-face in the classroom or via remote attendance. Remote attendance connects students to a live classroom presentation that includes a mix of in-person and remote students. You decide which courses to attend in person or remotely. All programming courses include at least 50% of time performing comprehensive hands on exercises facilitated by expert instructors. This boosts retention and confidence as well as assuring competency with the new skills being acquired.

Our self-directed scheduling allows you the flexibility you require to complete your training in the time frame you need.
